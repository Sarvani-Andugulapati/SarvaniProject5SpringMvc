package com.gl.CRM.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.CRM.dao.CustomerDao;
import com.gl.CRM.model.Customer;

@Controller
@RequestMapping("customers")
public class CustomerController {
	@Autowired
	CustomerDao customerdao;
	@GetMapping("list")
	public String customerList(Model model) {
		List<Customer>customers = customerdao.findAll();
		model.addAttribute("customers", customers);
		return "customer-list";
	}
	@GetMapping("add")
	public String addCustomer(Model model) {
		Customer cs = new Customer();
		model.addAttribute("customer", cs);
		return "customer-add";
	}
	@GetMapping("index")
	public String crmHome() {
		return "index";
	}
	@PostMapping("save")
	public String saveCustomerdata(Model model,@ModelAttribute("customer")Customer customer) {
		customerdao.createCustomer(customer);
		return "redirect:/customers/list";
	}
	@GetMapping("Update")
	public String updateCustomer(Model model, @RequestParam("id")int id) {
		Customer customer = customerdao.findById(id);
		System.out.println(customer);
		model.addAttribute("customer",customer);
		return "update";
	}
	@GetMapping("delete")
	public String deleteCustomer(Model model, @RequestParam("id")int id) {
		customerdao.deleteCustomer(id);
		return "redirect:/customers/list";
	}

}
