package com.gl.CRM.dao;

import java.util.List;

import com.gl.CRM.model.Customer;

public interface CustomerDao {
public void createCustomer(Customer customer);
public void deleteCustomer(int id);
public Customer findById(int id);
public List<Customer>findAll();
}
