package com.gl.CRM.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gl.CRM.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	@Autowired
	SessionFactory factory;

	@Override
	@Transactional
	public void createCustomer(Customer customer) {
		Session session = factory.getCurrentSession();
		session.saveOrUpdate(customer);
	}

	@Override
	@Transactional
	public void deleteCustomer(int id) {
		Session session = factory.getCurrentSession();
		Customer cs = session.get(Customer.class, id);
		session.delete(cs);
	}

	@Override
	@Transactional
	public Customer findById(int id) {
		Session session = factory.getCurrentSession();
		return session.get(Customer.class, id);
	}

	//@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	@Transactional
	public List<Customer> findAll() {
		Session session = factory.getCurrentSession();
		Criteria ct = session.createCriteria(Customer.class);
		return ct.list();
	}

}
